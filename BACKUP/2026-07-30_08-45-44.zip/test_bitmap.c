/*
 * test_bitmap.c
 * Minimal multicolor bitmap mode test for C64 / cc65.
 * Should show a white vertical bar on a blue background.
 */

#include <c64.h>
#include <peekpoke.h>

#define VPoke(a,v) (*(volatile unsigned char*)(a) = (v))
#define VPeek(a)   (*(volatile unsigned char*)(a))

#define SCREEN_RAM  0x0400u
#define BITMAP_RAM  0x2000u
#define COLOR_RAM   ((unsigned char*)0xD800)

int main(void)
{
    unsigned char y;
    unsigned char *row;

    /* VIC bank 0 */
    VPoke(0xDD02, 0x3F);
    VPoke(0xDD00, (VPeek(0xDD00) & 0xFC) | 0x03);

    /* Screen $0400, bitmap $2000 */
    VPoke(0xD018, 0x18);

    /* Multicolor bitmap mode */
    VPoke(0xD011, VPeek(0xD011) | 0x20);
    VPoke(0xD016, VPeek(0xD016) | 0x10);

    /* Colors: blue background/border, white color RAM */
    VPoke(0xD020, 0x06);
    VPoke(0xD021, 0x06);

    /* Screen RAM nibbles both blue -> 01/10 pixels also blue */
    {
        unsigned int i;
        for (i = 0; i < 1000; ++i)
            ((unsigned char*)SCREEN_RAM)[i] = 0x66;
        for (i = 0; i < 1000; ++i)
            COLOR_RAM[i] = 0x01;
        for (i = 0; i < 8000; ++i)
            ((unsigned char*)BITMAP_RAM)[i] = 0x00;
    }

    /* Draw a white vertical bar at multicolor column 10 (byte 2..3, all bits 11) */
    for (y = 20; y < 180; ++y)
    {
        row = (unsigned char*)(BITMAP_RAM + y * 40u + 10u);
        row[0] = 0xFF; /* 11111111 = 4 white pixels */
        row[1] = 0xFF;
        row[2] = 0xFF;
        row[3] = 0xFF;
    }

    for (;;) { }
}
