/*
 * test_vic.c - Minimal test for VIC multicolor bitmap mode
 */

#include <c64.h>
#include <peekpoke.h>
#include <string.h>

#define VPoke(a,v)  (*(volatile unsigned char*)(a) = (v))
#define VPeek(a)    (*(volatile unsigned char*)(a))

/* VIC bank 1 ($4000-$7FFF) */
#define VIC_BANK     1u
#define BANK_BASE    0x4000u
#define BITMAP_ADDR  (BANK_BASE + 0x2000u)   /* $6000 */
#define SCREEN_ADDR  (BANK_BASE + 0x1C00u)   /* $5C00 */
#define ROM_CHARSET  0xD000u

int main(void)
{
    unsigned char i;
    unsigned char c, col;
    
    /* Disable interrupts */
    asm("sei");
    
    /* VIC to bank 1 */
    VPoke(0xDD02, VPeek(0xDD02) | 0x03);
    VPoke(0xDD00, (VPeek(0xDD00) & 0xFC) | (3u - VIC_BANK));
    
    /* Screen at $1C00, bitmap at $2000 */
    VPoke(0xD018, 0x78);
    
    /* Bitmap mode + display on + multicolor */
    VIC.ctrl1 = 0x1B;
    VIC.ctrl2 = 0x18;
    
    /* Colors */
    VIC.bordercolor = 6;
    VIC.bgcolor0 = 0;
    VIC.bgcolor1 = 0;
    VIC.bgcolor2 = 0;
    VIC.bgcolor3 = 1;
    
    /* Clear bitmap */
    memset((void *)BITMAP_ADDR, 0x00, 8000);
    
    /* Set screen RAM colors */
    for (i = 0; i < 1000; i++) {
        ((unsigned char *)SCREEN_ADDR)[i] = 0x11;
    }
    
    /* Clear color RAM */
    memset((void *)0xD800, 0x00, 1000);
    
    /* Draw character 'A' (PETSCII 0x01) at screen position 0,0 using ROM charset */
    /* Screen row 0 = bitmap offset 0, column 0 = offset 0 */
    for (i = 0; i < 8; i++) {
        c = VPeek(ROM_CHARSET + 0x01 * 8 + i);  /* Character 'A' */
        /* Convert hi-res to multicolor */
        col = 0;
        if (c & 0x80) col |= 0x02;
        if (c & 0x40) col |= 0x02;
        if (c & 0x20) col |= 0x08;
        if (c & 0x10) col |= 0x08;
        if (c & 0x08) col |= 0x20;
        if (c & 0x04) col |= 0x20;
        if (c & 0x02) col |= 0x80;
        if (c & 0x01) col |= 0x80;
        VPoke(BITMAP_ADDR + i, col);
    }
    
    /* Set color RAM for first row to white */
    for (i = 0; i < 40; i++) {
        VPoke(0xD800 + i, 0x01);
    }
    
    /* Main loop - do nothing */
    for (;;) {
        asm("nop");
    }
}
