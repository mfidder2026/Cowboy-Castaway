/*
 * test_simple.c - Minimal VIC test
 */

#include <c64.h>
#include <peekpoke.h>

#define VPoke(a,v)  (*(volatile unsigned char*)(a) = (v))
#define VPeek(a)    (*(volatile unsigned char*)(a))

int main(void)
{
    /* Disable interrupts */
    asm("sei");
    
    /* Just set colors - no bitmap mode */
    VIC.bordercolor = 2;   /* Red border */
    VIC.bgcolor0 = 6;      /* Brown background */
    
    /* Main loop */
    for (;;) {
        asm("nop");
    }
}
