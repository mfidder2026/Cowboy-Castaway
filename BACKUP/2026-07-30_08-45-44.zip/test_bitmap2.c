/*
 * test_bitmap2.c - Working multicolor bitmap test
 */

#include <c64.h>
#include <peekpoke.h>
#include <string.h>

#define VPoke(a,v)  (*(volatile unsigned char*)(a) = (v))
#define VPeek(a)    (*(volatile unsigned char*)(a))

/* VIC bank 1 ($4000-$7FFF) */
#define VIC_BANK     1u
#define BANK_BASE    0x4000u
#define BITMAP_ADDR  (BANK_BASE + 0x2000u)   /* $6000 */
#define SCREEN_ADDR  (BANK_BASE + 0x1C00u)   /* $5C00 */

int main(void)
{
    unsigned char i, j;
    
    /* Disable interrupts */
    asm("sei");
    
    /* VIC to bank 1 */
    VPoke(0xDD02, VPeek(0xDD02) | 0x03);
    VPoke(0xDD00, (VPeek(0xDD00) & 0xFC) | (3u - VIC_BANK));
    
    /* Screen at $1C00, bitmap at $2000 */
    VPoke(0xD018, 0x78);
    
    /* Bitmap mode + display on + multicolor
     * $D011: DEN (bit 4) + BMM (bit 5) = 0x30 + Y-scroll bits
     * $D016: MCM (bit 4) = 0x10 + X-scroll bits */
    VIC.ctrl1 = 0x3B;       /* DEN + BMM + smooth scroll cleared */
    VIC.ctrl2 = 0x18;       /* MCM + smooth scroll cleared */
    
    /* Colors */
    VIC.bordercolor = 1;    /* White border */
    VIC.bgcolor0 = 0;       /* Black background (color 00) */
    VIC.bgcolor1 = 0;
    VIC.bgcolor2 = 0;
    VIC.bgcolor3 = 7;       /* Yellow (color 11 from bitmap) */
    
    /* Clear bitmap to all zeros (all pixels = color 00 = black) */
    memset((void *)BITMAP_ADDR, 0x00, 8000);
    
    /* Set up screen RAM:
     * Each byte controls colors for one 4x8 cell:
     * - bits 0-3: color for "01" pattern
     * - bits 4-7: color for "10" pattern */
    for (i = 0; i < 1000; i++) {
        ((unsigned char *)SCREEN_ADDR)[i] = 0xEF;  /* 01=white(1), 10=yellow(14) */
    }
    
    /* Clear color RAM (color for "11" pattern) */
    memset((void *)0xD800, 0x00, 1000);
    
    /* Draw a simple pattern in the top-left corner
     * First 4x8 cell: all pixels = color 10 (yellow) */
    for (i = 0; i < 8; i++) {
        /* Pattern: 10 10 10 10 = 0xAA */
        VPoke(BITMAP_ADDR + i, 0xAA);
    }
    
    /* Set color RAM for first row to red (color 11) */
    for (i = 0; i < 40; i++) {
        VPoke(0xD800 + i, 2);
    }
    
    /* Main loop */
    for (;;) {
        asm("nop");
    }
}
