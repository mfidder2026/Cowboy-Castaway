/*
 * test_bitmap3.c - Working multicolor bitmap test v3
 */

#include <c64.h>
#include <peekpoke.h>
#include <string.h>

#define VPoke(a,v)  (*(volatile unsigned char*)(a) = (v))
#define VPeek(a)    (*(volatile unsigned char*)(a))

/* VIC bank 1 ($4000-$7FFF) */
#define VIC_BANK     1u
#define BANK_BASE    0x4000u
#define BITMAP_ADDR  (BANK_BASE + 0x2000u)   /* $6000 */
#define SCREEN_ADDR  (BANK_BASE + 0x1C00u)   /* $5C00 */

int main(void)
{
    unsigned int i;
    
    /* Disable interrupts */
    asm("sei");
    
    /* VIC to bank 1 */
    VPoke(0xDD02, VPeek(0xDD02) | 0x03);
    VPoke(0xDD00, (VPeek(0xDD00) & 0xFC) | (3u - VIC_BANK));
    
    /* Screen at $1C00, bitmap at $2000 */
    VPoke(0xD018, 0x78);
    
    /* Bitmap mode + display on + multicolor
     * $D011: DEN(bit4)=1, BMM(bit5)=1, RST8(bit3)=1 -> 0x3B
     * $D016: MCM(bit4)=1, ECM(bit3)=0 -> 0x18 is WRONG! Should be 0x10 */
    VIC.ctrl1 = 0x3B;
    VIC.ctrl2 = 0x10;      /* MCM only, NO ECM! */
    
    /* Colors */
    VIC.bordercolor = 1;    /* White border */
    VIC.bgcolor0 = 0;       /* Black (color 00) */
    
    /* Fill bitmap with 0xFF = pattern 11 11 11 11 (all pixels = color 11) */
    memset((void *)BITMAP_ADDR, 0xFF, 8000);
    
    /* Set up screen RAM - doesn't matter for pattern 11 */
    memset((void *)SCREEN_ADDR, 0x00, 1000);
    
    /* Fill color RAM with white (color 1) */
    for (i = 0; i < 1000; i++) {
        VPoke(0xD800 + i, 1);
    }
    
    /* Main loop */
    for (;;) {
        asm("nop");
    }
}
