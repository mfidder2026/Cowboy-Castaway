/*
 * scroller.c - Smooth multicolor bitmap text scroller for C64
 * ============================================================
 *
 * Memory layout (VIC bank 1: $4000-$7FFF):
 *   $6000-$7F37 - Bitmap (8000 bytes)
 *   $5C00-$5FE7 - Screen RAM (1000 bytes)
 *   $D800-$DBE7 - Color RAM (always at this address)
 *
 * Compile: cl65 -O -t c64 scroller.c -o scroller.prg
 * Run:     x64sc -autostart scroller.prg
 */

#include <c64.h>
#include <peekpoke.h>
#include <string.h>

#define VPoke(a,v)  (*(volatile unsigned char*)(a) = (v))
#define VPeek(a)    (*(volatile unsigned char*)(a))

/* VIC bank 1 ($4000-$7FFF) - same as main.c */
#define VIC_BANK     1u
#define BANK_BASE    0x4000u

/* Memory addresses in VIC bank 1 */
#define BITMAP_ADDR  (BANK_BASE + 0x2000u)   /* $6000 */
#define SCREEN_ADDR  (BANK_BASE + 0x1C00u)   /* $5C00 */
#define ROM_CHARSET  0xD000u

/* Scroller settings */
#define SCROLLER_Y   12    /* Character row (0-24) */

/* Colors */
#define COL_BG       0x00   /* black */
#define COL_BORDER   0x00   /* black border */
#define COL_TEXT     0x01   /* white text */

/* The scroll message */
static const char scroll_text[] = 
    "COWBOY CASTAWAY SCREENSAVER BROUGHT TO YOU BY RETRO8BITSHOP *** PRESS SPACE TO CONTINUE *** ";

/* Pixel offset for hardware smooth scroll (0-7) */
static unsigned char pixel_scroll = 0;

/* Character offset in scroll text */
static unsigned int char_offset = 0;

/* Convert ASCII to PETSCII index for ROM charset */
static unsigned char to_petscii(unsigned char c)
{
    if (c >= 'A' && c <= 'Z') return c - 'A' + 1;
    if (c >= 'a' && c <= 'z') return c - 'a' + 1;
    if (c >= '0' && c <= '9') return c - '0' + 48;
    if (c == ' ') return 0x20;
    if (c == '*') return 0x2A;
    return 0x20;
}

/* Render a character from ROM charset into bitmap at position */
static void render_char(unsigned char bx, unsigned char petscii_idx)
{
    unsigned char line;
    unsigned int offset;
    const unsigned char *char_data = (const unsigned char *)(ROM_CHARSET + petscii_idx * 8u);
    /* bx is char column (0-39), SCROLLER_Y is char row (0-24)
     * In multicolor bitmap mode (320x200):
     * - Bitmap is linear: 8000 bytes total
     * - Each scanline = 320 pixels / 4 = 80 bytes
     * - Each char cell = 4x8 pixels = 8 bytes wide, 8 scanlines high
     * - Char at (col, row) starts at: row * 640 + col * 8
     * - Each scanline within char adds 80 bytes */
    
    for (line = 0; line < 8; line++) {
        unsigned char pattern = char_data[line];
        unsigned char col = 0;
        
        /* Convert hi-res pattern to multicolor */
        /* Each bit pair becomes one multicolor pixel (2 bits) */
        if (pattern & 0x80) col |= 0x02;
        if (pattern & 0x40) col |= 0x02;
        if (pattern & 0x20) col |= 0x08;
        if (pattern & 0x10) col |= 0x08;
        if (pattern & 0x08) col |= 0x20;
        if (pattern & 0x04) col |= 0x20;
        if (pattern & 0x02) col |= 0x80;
        if (pattern & 0x01) col |= 0x80;
        
        /* Bitmap offset: (char_row * 8 scanlines * 80 bytes) + (char_col * 8 bytes) + (line * 80 bytes)
         * = row * 640 + col * 8 + line * 80 */
        offset = (unsigned int)SCROLLER_Y * 640u + (unsigned int)bx * 8u + (unsigned int)line * 80u;
        VPoke(BITMAP_ADDR + offset, col);
    }
}

/* Setup VIC-II for multicolor bitmap mode - based on main.c setup_background() */
static void setup_vic(void)
{
    unsigned char i;
    
    /* 1. VIC to bank 1 ($4000-$7FFF) via CIA2 port A.
     *    Bits 0-1 are inverted: bank value = 3 - bank */
    VPoke(0xDD02, VPeek(0xDD02) | 0x03);      /* bits as output */
    VPoke(0xDD00, (VPeek(0xDD00) & 0xFC) | (3u - VIC_BANK));
    
    /* 2. Screen at offset $1C00, bitmap at offset $2000 within bank.
     *    $D018 = (screen/1024)<<4 | (bitmap/8192)<<3 = 7<<4 | 1<<3 = 0x78 */
    VPoke(0xD018, 0x78);
    
    /* 3. Bitmap mode + multicolor on + display enabled
     *    Use |= like main.c to preserve other bits */
    VIC.ctrl1 |= 0x18;      /* Set BMM (bit 5) and DEN (bit 4) */
    VIC.ctrl2 |= 0x10;      /* Set MCM (bit 4) */
    
    /* Set colors */
    VIC.bordercolor = COL_BORDER;
    VIC.bgcolor0 = COL_BG;
    VIC.bgcolor1 = COL_BG;
    VIC.bgcolor2 = COL_BG;
    VIC.bgcolor3 = COL_TEXT;
    
    /* Clear bitmap */
    memset((void *)BITMAP_ADDR, 0x00, 8000);
    
    /* Clear screen RAM and set color attributes for each cell
     * In multicolor bitmap mode, each screen byte defines colors:
     * - bits 0-3: color for "01" pattern
     * - bits 4-7: color for "10" pattern */
    for (i = 0; i < 1000; i++) {
        ((unsigned char *)SCREEN_ADDR)[i] = (COL_TEXT << 4) | COL_TEXT;
    }
    
    /* Clear color RAM */
    memset((void *)0xD800, 0x00, 1000);
    
    /* Set colors for scroller row in color RAM (color 11) */
    for (i = 0; i < 40; i++) {
        VPoke(0xD800 + SCROLLER_Y * 40 + i, (COL_TEXT << 4) | COL_BG);
    }
}

/* Render text line into bitmap at scroller row */
static void render_text_line(void)
{
    unsigned char bx;
    unsigned int text_len = sizeof(scroll_text) - 1;
    
    /* Calculate bitmap offset for screen row SCROLLER_Y
     * In multicolor bitmap mode, each screen char = 8 bytes in bitmap
     * Screen row starts at bitmap offset: (row * 40 * 8) */
    unsigned int row_offset = (unsigned int)SCROLLER_Y * 320u;
    
    for (bx = 0; bx < 40; bx++) {
        unsigned int idx = (char_offset + bx) % text_len;
        unsigned char petscii = to_petscii((unsigned char)scroll_text[idx]);
        render_char(bx, petscii);
        (void)row_offset;
    }
}

/* Shift bitmap left by one byte (8 pixels) for one character row */
static void shift_bitmap_left(void)
{
    unsigned char bx, line;
    unsigned int row_base = (unsigned int)SCROLLER_Y * 320u;  /* 40 chars * 8 bytes */
    
    for (bx = 0; bx < 39; bx++) {
        for (line = 0; line < 8; line++) {
            unsigned int off = row_base + (unsigned int)bx * 8u + line;
            unsigned int off_next = off + 8;
            VPoke(BITMAP_ADDR + off, VPeek(BITMAP_ADDR + off_next));
        }
    }
    
    /* Clear rightmost character */
    for (line = 0; line < 8; line++) {
        unsigned int off = row_base + 39u * 8u + line;
        VPoke(BITMAP_ADDR + off, 0x00);
    }
}

/* Wait for specific raster line */
static void wait_raster(unsigned char line)
{
    while (VPeek(0xD012) != line);
}

/* Main */
int main(void)
{
    unsigned int idx;
    
    /* Disable interrupts */
    asm("sei");
    
    setup_vic();
    render_text_line();
    
    /* Main loop */
    for (;;) {
        /* Sync to vertical blank */
        wait_raster(250);
        
        /* Apply smooth scroll (0-7 pixels) - preserve multicolor bit (bit 4) */
        VIC.ctrl2 = (VIC.ctrl2 & 0xF8) | 0x10 | (pixel_scroll & 0x07);
        
        /* Every 8 pixels, shift and update */
        if (pixel_scroll == 0) {
            shift_bitmap_left();
            
            /* Render new character at right edge */
            idx = (char_offset + 39) % (sizeof(scroll_text) - 1);
            render_char(39, to_petscii((unsigned char)scroll_text[idx]));
            
            char_offset++;
            if (char_offset >= sizeof(scroll_text) - 1) {
                char_offset = 0;
            }
        }
        
        pixel_scroll++;
        if (pixel_scroll > 7) {
            pixel_scroll = 0;
        }
    }
}
