/*
 * test_main_style.c - Test multicolor bitmap using exact main.c approach
 */
#include <c64.h>
#include <peekpoke.h>
#include <string.h>

#define VIC_BANK     1u
#define BANK_BASE    0x4000u
#define SCREEN_ADDR  (BANK_BASE + 0x1C00u)   /* $5C00 */
#define BITMAP_ADDR  (BANK_BASE + 0x2000u)   /* $6000 */

int main(void)
{
    unsigned char i;
    
    /* Disable interrupts */
    asm("sei");
    
    /* 1. VIC to bank 1 ($4000-$7FFF) via CIA2 port A - exactly like main.c */
    POKE(0xDD02, PEEK(0xDD02) | 0x03);
    POKE(0xDD00, (PEEK(0xDD00) & 0xFC) | (3u - VIC_BANK));
    
    /* 2. Screen at $1C00, bitmap at $2000 - exactly like main.c */
    POKE(0xD018, 0x78);
    
    /* 3. Bitmap mode + multicolor - exactly like main.c */
    VIC.ctrl1 |= 0x20;
    VIC.ctrl2 |= 0x10;
    
    /* 4. Colors */
    VIC.bordercolor = 2;  /* red */
    VIC.bgcolor0 = 6;     /* blue */
    
    /* 5. Clear bitmap to blue (color 1 pattern = blue) */
    memset((void *)BITMAP_ADDR, 0x55, 8000);
    
    /* 6. Setup screen RAM - each byte controls colors for that cell */
    for (i = 0; i < 1000; i++) {
        ((unsigned char *)SCREEN_ADDR)[i] = 0x01;  /* colors 0 and 1 */
    }
    
    /* Infinite loop */
    for (;;) {
    }
}
